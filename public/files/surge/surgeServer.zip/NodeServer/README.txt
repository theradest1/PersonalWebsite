to start the server:
make sure node is installed, if not download/install from here: https://nodejs.org/en/download
go to this folder in the terminal
run "node app.js"
join the server by joining "localhost" in the server selector

if you get an error of need clarification talk to me in the discord (: